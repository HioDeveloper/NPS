package main

import (
	"fmt"
	"os"

	"nps/pkg/compiler"
	"nps/pkg/manager"
)

func main() {
	if len(os.Args) < 2 {
		printUsage()
		os.Exit(1)
	}

	cmd := os.Args[1]
	mgr := manager.NewManager(defaultRepo)

	switch cmd {
	case "build":
		if len(os.Args) < 3 {
			fmt.Println("Usage: nps build <source.nps>")
			os.Exit(1)
		}
		src := os.Args[2]
		if err := compiler.Compile(src); err != nil {
			fmt.Printf("Compilation error: %v\n", err)
			os.Exit(1)
		}
		fmt.Println("Build successful. Output: program")

	case "run":
		if len(os.Args) < 3 {
			fmt.Println("Usage: nps run <source.nps>")
			os.Exit(1)
		}
		src := os.Args[2]
		if err := compiler.Run(src); err != nil {
			fmt.Printf("Runtime error: %v\n", err)
			os.Exit(1)
		}

	case "install":
		if len(os.Args) < 3 {
			fmt.Println("Usage: nps install <libname>")
			os.Exit(1)
		}
		lib := os.Args[2]
		if err := mgr.Install(lib); err != nil {
			fmt.Printf("Error: %v\n", err)
			os.Exit(1)
		}

	case "list":
		if err := mgr.List(); err != nil {
			fmt.Printf("Error: %v\n", err)
			os.Exit(1)
		}

	case "remove":
		if len(os.Args) < 3 {
			fmt.Println("Usage: nps remove <libname>")
			os.Exit(1)
		}
		lib := os.Args[2]
		if err := mgr.Remove(lib); err != nil {
			fmt.Printf("Error: %v\n", err)
			os.Exit(1)
		}

	case "update":
		if len(os.Args) < 3 {
			libs, err := mgr.ListInstalled()
			if err != nil {
				fmt.Printf("Error: %v\n", err)
				os.Exit(1)
			}
			for _, lib := range libs {
				fmt.Printf("Updating %s...\n", lib)
				if err := mgr.Update(lib); err != nil {
					fmt.Printf("  failed: %v\n", err)
				}
			}
		} else {
			lib := os.Args[2]
			if err := mgr.Update(lib); err != nil {
				fmt.Printf("Error: %v\n", err)
				os.Exit(1)
			}
		}

	default:
		fmt.Printf("Unknown command: %s\n", cmd)
		printUsage()
		os.Exit(1)
	}
}

const defaultRepo = "https://hiosw.myarena.site/nps-libs"

func printUsage() {
	fmt.Println(`Usage:
  nps build <source.nps>      Compile an NPS program (requires Go)
  nps run <source.nps>        Run an NPS program (no Go required)
  nps install <libname>       Install a library
  nps list                    List installed libraries
  nps remove <libname>        Remove a library
  nps update [<libname>]      Update library (or all)
`)
}
