module nps

go 1.22
