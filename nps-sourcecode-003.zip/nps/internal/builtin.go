package internal

// BuiltinLibs содержит встроенные библиотеки (пока не используется)
var BuiltinLibs = map[string]string{
	"lib": `# встроенная библиотека lib уже реализована в runtime`,
}
