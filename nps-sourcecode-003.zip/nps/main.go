package main

import (
  "fmt"
  "nps/pkg/runtime"
)

func npsMain() {
  fmt.Println("Hello from NPS")
  runtime.Action(1)
  runtime.Action(0)
}

func main() {
  fmt.Println("NPS engine started")
  npsMain()
}
