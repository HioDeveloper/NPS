package ast

import "fmt"

type Node interface {
	TokenLiteral() string
	String() string
}

type Program struct {
	Includes []string
	Defines  map[string]string
	Tasks    []*TaskStmt
	Safe     *SafeStmt
}

func (p *Program) TokenLiteral() string { return "" }
func (p *Program) String() string {
	out := ""
	for _, inc := range p.Includes {
		out += "#include " + inc + "\n"
	}
	for k, v := range p.Defines {
		out += "#define " + k + " " + v + "\n"
	}
	for _, t := range p.Tasks {
		out += t.String() + "\n"
	}
	if p.Safe != nil {
		out += p.Safe.String() + "\n"
	}
	return out
}

type Expr interface {
	Node
	exprNode()
}

// --- выражения ---

type IdentExpr struct {
	Name string
	Line int
}

func (e *IdentExpr) TokenLiteral() string { return e.Name }
func (e *IdentExpr) String() string       { return e.Name }
func (e *IdentExpr) exprNode()            {}

type NumberExpr struct {
	Value int
	Line  int
}

func (e *NumberExpr) TokenLiteral() string { return fmt.Sprintf("%d", e.Value) }
func (e *NumberExpr) String() string       { return fmt.Sprintf("%d", e.Value) }
func (e *NumberExpr) exprNode()            {}

type IPExpr struct {
	Value string
	Line  int
}

func (e *IPExpr) TokenLiteral() string { return e.Value }
func (e *IPExpr) String() string       { return e.Value }
func (e *IPExpr) exprNode()            {}

type StringExpr struct {
	Value string
	Line  int
}

func (e *StringExpr) TokenLiteral() string { return "\"" + e.Value + "\"" }
func (e *StringExpr) String() string       { return "\"" + e.Value + "\"" }
func (e *StringExpr) exprNode()            {}

type CallExpr struct {
	Func string
	Args []Expr
	Line int
}

func (e *CallExpr) TokenLiteral() string { return e.Func }
func (e *CallExpr) String() string {
	out := e.Func + "("
	for i, a := range e.Args {
		if i > 0 {
			out += ", "
		}
		out += a.String()
	}
	out += ")"
	return out
}
func (e *CallExpr) exprNode() {}

type BinOpExpr struct {
	Left  Expr
	Op    string
	Right Expr
	Line  int
}

func (e *BinOpExpr) TokenLiteral() string { return e.Op }
func (e *BinOpExpr) String() string {
	return e.Left.String() + " " + e.Op + " " + e.Right.String()
}
func (e *BinOpExpr) exprNode() {}

type UnaryExpr struct {
	Op    string
	Right Expr
	Line  int
}

func (e *UnaryExpr) TokenLiteral() string { return e.Op }
func (e *UnaryExpr) String() string {
	return e.Op + e.Right.String()
}
func (e *UnaryExpr) exprNode() {}

// --- операторы ---

type LetStmt struct {
	Name    string
	Type    string
	Mutable bool
	Value   Expr
	Line    int
}

func (s *LetStmt) TokenLiteral() string { return "let" }
func (s *LetStmt) String() string {
	out := "let "
	if s.Mutable {
		out = "mut "
	}
	out += s.Name
	if s.Type != "" {
		out += ": " + s.Type
	}
	out += " = " + s.Value.String()
	return out
}

type AssignStmt struct {
	Name  string
	Value Expr
	Line  int
}

func (s *AssignStmt) TokenLiteral() string { return "=" }
func (s *AssignStmt) String() string {
	return s.Name + " = " + s.Value.String()
}

type ReturnStmt struct {
	Value Expr
	Line  int
}

func (s *ReturnStmt) TokenLiteral() string { return "return" }
func (s *ReturnStmt) String() string {
	return "return " + s.Value.String()
}

type BlockStmt struct {
	Statements []Node
	Line       int
}

func (s *BlockStmt) TokenLiteral() string { return "{" }
func (s *BlockStmt) String() string {
	out := "{\n"
	for _, stmt := range s.Statements {
		out += "  " + stmt.String() + "\n"
	}
	out += "}"
	return out
}

type TaskStmt struct {
	Name   string
	Params []struct{ Name, Type string }
	Body   *BlockStmt
	Line   int
}

func (s *TaskStmt) TokenLiteral() string { return "task" }
func (s *TaskStmt) String() string {
	out := "task " + s.Name + "("
	for i, p := range s.Params {
		if i > 0 {
			out += ", "
		}
		out += p.Name + ": " + p.Type
	}
	out += ") " + s.Body.String()
	return out
}

type MatchCase struct {
	Pattern Expr
	Action  Node
}
type MatchStmt struct {
	Value Expr
	Cases []MatchCase
	Line  int
}

func (s *MatchStmt) TokenLiteral() string { return "match" }
func (s *MatchStmt) String() string {
	out := "match " + s.Value.String() + " {\n"
	for _, c := range s.Cases {
		out += "  " + c.Pattern.String() + " -> " + c.Action.String() + "\n"
	}
	out += "}"
	return out
}

type IfStmt struct {
	Condition Expr
	Then      *BlockStmt
	Else      *BlockStmt
	Line      int
}

func (s *IfStmt) TokenLiteral() string { return "if" }
func (s *IfStmt) String() string {
	out := "if " + s.Condition.String() + " " + s.Then.String()
	if s.Else != nil {
		out += " else " + s.Else.String()
	}
	return out
}

type WhileStmt struct {
	Condition Expr
	Body      *BlockStmt
	Line      int
}

func (s *WhileStmt) TokenLiteral() string { return "while" }
func (s *WhileStmt) String() string {
	return "while " + s.Condition.String() + " " + s.Body.String()
}

type SafeStmt struct {
	MaxProcesses int
	Body         *BlockStmt
	Line         int
}

func (s *SafeStmt) TokenLiteral() string { return "safe" }
func (s *SafeStmt) String() string {
	return fmt.Sprintf("safe(max_processes = %d) %s", s.MaxProcesses, s.Body.String())
}
