package compiler

import (
	"fmt"
	"strconv"
	"strings"

	"nps/pkg/ast"
)

type CodeGenerator struct {
	out     strings.Builder
	indent  int
	defines map[string]string
}

func NewCodeGenerator() *CodeGenerator {
	return &CodeGenerator{defines: make(map[string]string)}
}

func (cg *CodeGenerator) indentStr() string {
	return strings.Repeat("  ", cg.indent)
}

func (cg *CodeGenerator) Generate(prog *ast.Program) string {
	cg.out.Reset()
	cg.defines = prog.Defines

	cg.out.WriteString("package main\n\n")
	cg.out.WriteString("import (\n")
	cg.out.WriteString("  \"fmt\"\n")
	cg.out.WriteString("  \"nps/pkg/runtime\"\n")
	cg.out.WriteString(")\n\n")

	for k, v := range prog.Defines {
		cg.out.WriteString(fmt.Sprintf("const %s = %s\n", k, v))
	}
	if len(prog.Defines) > 0 {
		cg.out.WriteString("\n")
	}

	for _, task := range prog.Tasks {
		cg.generateTask(task)
	}

	hasMain := false
	for _, t := range prog.Tasks {
		if t.Name == "main" {
			hasMain = true
			break
		}
	}
	if hasMain {
		cg.out.WriteString("func main() {\n")
		cg.indent++
		cg.out.WriteString(cg.indentStr() + "fmt.Println(\"NPS engine started\")\n")
		cg.out.WriteString(cg.indentStr() + "npsMain()\n")
		cg.indent--
		cg.out.WriteString("}\n")
	}

	return cg.out.String()
}

func (cg *CodeGenerator) generateTask(task *ast.TaskStmt) {
	funcName := task.Name
	if funcName == "main" {
		funcName = "npsMain"
	}
	cg.out.WriteString("func " + funcName + "(")
	for i, p := range task.Params {
		if i > 0 {
			cg.out.WriteString(", ")
		}
		cg.out.WriteString(p.Name + " " + cg.goType(p.Type))
	}
	cg.out.WriteString(") {\n")
	cg.indent++
	cg.generateBlock(task.Body, false)
	cg.indent--
	cg.out.WriteString("}\n\n")
}

func (cg *CodeGenerator) generateBlock(block *ast.BlockStmt, needBraces bool) {
	if needBraces {
		cg.out.WriteString("{\n")
		cg.indent++
	}
	for _, stmt := range block.Statements {
		switch s := stmt.(type) {
		case *ast.LetStmt:
			cg.generateLet(s)
		case *ast.AssignStmt:
			cg.generateAssign(s)
		case *ast.ReturnStmt:
			cg.generateReturn(s)
		case *ast.CallExpr:
			cg.generateCall(s)
		case *ast.IfStmt:
			cg.generateIf(s)
		case *ast.WhileStmt:
			cg.generateWhile(s)
		case *ast.MatchStmt:
			cg.generateMatch(s)
		case *ast.BlockStmt:
			cg.generateBlock(s, true)
		default:
			cg.out.WriteString(cg.indentStr() + "// unknown statement\n")
		}
	}
	if needBraces {
		cg.indent--
		cg.out.WriteString(cg.indentStr() + "}\n")
	}
}

func (cg *CodeGenerator) generateLet(let *ast.LetStmt) {
	cg.out.WriteString(cg.indentStr())
	if let.Mutable {
		cg.out.WriteString("var ")
	} else {
		cg.out.WriteString("")
	}
	cg.out.WriteString(let.Name + " := ")
	cg.generateExpr(let.Value)
	cg.out.WriteString("\n")
}

func (cg *CodeGenerator) generateAssign(assign *ast.AssignStmt) {
	cg.out.WriteString(cg.indentStr() + assign.Name + " = ")
	cg.generateExpr(assign.Value)
	cg.out.WriteString("\n")
}

func (cg *CodeGenerator) generateReturn(ret *ast.ReturnStmt) {
	cg.out.WriteString(cg.indentStr() + "return ")
	if ret.Value != nil {
		cg.generateExpr(ret.Value)
	}
	cg.out.WriteString("\n")
}

func (cg *CodeGenerator) generateCall(call *ast.CallExpr) {
	cg.out.WriteString(cg.indentStr())
	if call.Func == "print" {
		cg.out.WriteString("fmt.Println(")
		for i, arg := range call.Args {
			if i > 0 {
				cg.out.WriteString(", ")
			}
			cg.generateExpr(arg)
		}
		cg.out.WriteString(")\n")
	} else if strings.HasPrefix(call.Func, "lib.") {
		goFunc := strings.TrimPrefix(call.Func, "lib.")
		if len(goFunc) > 0 {
			goFunc = string(goFunc[0]-32) + goFunc[1:]
		}
		cg.out.WriteString("runtime." + goFunc + "(")
		for i, arg := range call.Args {
			if i > 0 {
				cg.out.WriteString(", ")
			}
			cg.generateExpr(arg)
		}
		cg.out.WriteString(")\n")
	} else {
		cg.out.WriteString(call.Func + "(")
		for i, arg := range call.Args {
			if i > 0 {
				cg.out.WriteString(", ")
			}
			cg.generateExpr(arg)
		}
		cg.out.WriteString(")\n")
	}
}

func (cg *CodeGenerator) generateIf(ifStmt *ast.IfStmt) {
	cg.out.WriteString(cg.indentStr() + "if ")
	cg.generateExpr(ifStmt.Condition)
	cg.out.WriteString(" ")
	cg.generateBlock(ifStmt.Then, true)
	if ifStmt.Else != nil {
		cg.out.WriteString(cg.indentStr() + " else ")
		cg.generateBlock(ifStmt.Else, true)
	}
}

func (cg *CodeGenerator) generateWhile(while *ast.WhileStmt) {
	cg.out.WriteString(cg.indentStr() + "for ")
	cg.generateExpr(while.Condition)
	cg.out.WriteString(" ")
	cg.generateBlock(while.Body, true)
}

func (cg *CodeGenerator) generateMatch(match *ast.MatchStmt) {
	cg.out.WriteString(cg.indentStr() + "switch ")
	cg.generateExpr(match.Value)
	cg.out.WriteString(" {\n")
	cg.indent++
	for _, c := range match.Cases {
		cg.out.WriteString(cg.indentStr() + "case ")
		cg.generateExpr(c.Pattern)
		cg.out.WriteString(":\n")
		cg.indent++
		switch act := c.Action.(type) {
		case *ast.CallExpr:
			cg.generateCall(act)
		case *ast.BlockStmt:
			cg.generateBlock(act, false)
		default:
			cg.out.WriteString(cg.indentStr() + "// action\n")
		}
		cg.out.WriteString(cg.indentStr() + "break\n")
		cg.indent--
	}
	cg.indent--
	cg.out.WriteString(cg.indentStr() + "}\n")
}

func (cg *CodeGenerator) generateExpr(expr ast.Expr) {
	switch e := expr.(type) {
	case *ast.IdentExpr:
		cg.out.WriteString(e.Name)
	case *ast.NumberExpr:
		cg.out.WriteString(fmt.Sprintf("%d", e.Value))
	case *ast.IPExpr:
		parts := strings.Split(e.Value, ".")
		if len(parts) == 4 {
			a, _ := strconv.Atoi(parts[0])
			b, _ := strconv.Atoi(parts[1])
			c, _ := strconv.Atoi(parts[2])
			d, _ := strconv.Atoi(parts[3])
			val := uint32(a)<<24 | uint32(b)<<16 | uint32(c)<<8 | uint32(d)
			cg.out.WriteString(fmt.Sprintf("0x%08X", val))
		} else {
			cg.out.WriteString("/* invalid IP */")
		}
	case *ast.StringExpr:
		cg.out.WriteString("\"" + e.Value + "\"")
	case *ast.CallExpr:
		cg.out.WriteString(e.Func + "(")
		for i, a := range e.Args {
			if i > 0 {
				cg.out.WriteString(", ")
			}
			cg.generateExpr(a)
		}
		cg.out.WriteString(")")
	case *ast.BinOpExpr:
		cg.out.WriteString("(")
		cg.generateExpr(e.Left)
		cg.out.WriteString(" " + e.Op + " ")
		cg.generateExpr(e.Right)
		cg.out.WriteString(")")
	case *ast.UnaryExpr:
		cg.out.WriteString(e.Op)
		cg.generateExpr(e.Right)
	default:
		cg.out.WriteString("/* unknown expr */")
	}
}

func (cg *CodeGenerator) goType(t string) string {
	switch t {
	case "int":
		return "int"
	case "string":
		return "string"
	case "ip":
		return "runtime.IP"
	case "port":
		return "runtime.Port"
	case "packet":
		return "runtime.Packet"
	default:
		return "interface{}"
	}
}
