package compiler

import (
	"fmt"
	"io/ioutil"
	"os"
	"os/exec"

	"nps/pkg/interpreter"
	"nps/pkg/manager"
	"nps/pkg/parser"
)

func Compile(sourceFile string) error {
	data, err := ioutil.ReadFile(sourceFile)
	if err != nil {
		return fmt.Errorf("reading source: %v", err)
	}

	libPaths, _ := manager.GetLibPaths()
	p := parser.NewParser(string(data), libPaths)
	prog := p.ParseProgram()
	if len(p.Errors) > 0 {
		for _, e := range p.Errors {
			fmt.Println(e)
		}
		return fmt.Errorf("parser errors")
	}

	sem := NewSemanticAnalyzer()
	sem.Analyze(prog)
	if sem.HasErrors() {
		for _, e := range sem.GetErrors() {
			fmt.Println(e)
		}
		return fmt.Errorf("semantic errors")
	}

	gen := NewCodeGenerator()
	goCode := gen.Generate(prog)

	if err := ioutil.WriteFile("main.go", []byte(goCode), 0644); err != nil {
		return err
	}

	cmd := exec.Command("go", "build", "-o", "program", "main.go")
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	if err := cmd.Run(); err != nil {
		return fmt.Errorf("go build failed: %v", err)
	}

	fmt.Println("Compilation successful. Executable: ./program")
	return nil
}

func Run(sourceFile string) error {
	data, err := ioutil.ReadFile(sourceFile)
	if err != nil {
		return fmt.Errorf("reading source: %v", err)
	}

	libPaths, _ := manager.GetLibPaths()
	p := parser.NewParser(string(data), libPaths)
	prog := p.ParseProgram()
	if len(p.Errors) > 0 {
		for _, e := range p.Errors {
			fmt.Println(e)
		}
		return fmt.Errorf("parser errors")
	}

	sem := NewSemanticAnalyzer()
	sem.Analyze(prog)
	if sem.HasErrors() {
		for _, e := range sem.GetErrors() {
			fmt.Println(e)
		}
		return fmt.Errorf("semantic errors")
	}

	interp := interpreter.NewInterpreter()
	if err := interp.Run(prog); err != nil {
		return err
	}
	return nil
}
