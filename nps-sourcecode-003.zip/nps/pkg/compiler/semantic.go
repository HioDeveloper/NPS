package compiler

import (
	"fmt"

	"nps/pkg/ast"
)

type Symbol struct {
	Name    string
	Type    string
	Mutable bool
}

type Scope struct {
	parent  *Scope
	symbols map[string]Symbol
}

func NewScope(parent *Scope) *Scope {
	return &Scope{parent: parent, symbols: make(map[string]Symbol)}
}

func (s *Scope) Define(name string, typ string, mutable bool) {
	s.symbols[name] = Symbol{Name: name, Type: typ, Mutable: mutable}
}

func (s *Scope) Resolve(name string) (Symbol, bool) {
	if sym, ok := s.symbols[name]; ok {
		return sym, true
	}
	if s.parent != nil {
		return s.parent.Resolve(name)
	}
	return Symbol{}, false
}

type SemanticAnalyzer struct {
	errors []string
	scope  *Scope
}

func NewSemanticAnalyzer() *SemanticAnalyzer {
	return &SemanticAnalyzer{scope: NewScope(nil)}
}

func (sa *SemanticAnalyzer) Analyze(node ast.Node) {
	switch n := node.(type) {
	case *ast.Program:
		sa.scope.Define("print", "system", false)
		sa.scope.Define("lib", "system", false)
		for _, task := range n.Tasks {
			sa.analyzeTask(task)
		}
		if n.Safe != nil {
			sa.analyzeSafe(n.Safe)
		}
	case *ast.TaskStmt:
		sa.analyzeTask(n)
	case *ast.BlockStmt:
		sa.analyzeBlock(n)
	case *ast.LetStmt:
		sa.analyzeLet(n)
	case *ast.CallExpr:
		sa.analyzeCall(n)
	case *ast.MatchStmt:
		sa.analyzeMatch(n)
	}
}

func (sa *SemanticAnalyzer) analyzeTask(task *ast.TaskStmt) {
	scope := NewScope(sa.scope)
	oldScope := sa.scope
	sa.scope = scope
	for _, p := range task.Params {
		sa.scope.Define(p.Name, p.Type, false)
	}
	sa.analyzeBlock(task.Body)
	sa.scope = oldScope
}

func (sa *SemanticAnalyzer) analyzeBlock(block *ast.BlockStmt) {
	for _, stmt := range block.Statements {
		sa.Analyze(stmt)
	}
}

func (sa *SemanticAnalyzer) analyzeLet(let *ast.LetStmt) {
	if _, ok := sa.scope.Resolve(let.Name); ok {
		sa.errors = append(sa.errors, fmt.Sprintf("variable '%s' already declared at line %d", let.Name, let.Line))
	}
	typ := let.Type
	if typ == "" {
		typ = sa.inferType(let.Value)
	}
	sa.scope.Define(let.Name, typ, let.Mutable)
}

func (sa *SemanticAnalyzer) inferType(expr ast.Expr) string {
	switch expr.(type) {
	case *ast.NumberExpr:
		return "int"
	case *ast.StringExpr:
		return "string"
	case *ast.IPExpr:
		return "ip"
	default:
		return "unknown"
	}
}

func (sa *SemanticAnalyzer) analyzeCall(call *ast.CallExpr) {
	if call.Func == "print" {
		return
	}
	if call.Func == "lib.action" {
		if len(call.Args) != 1 {
			sa.errors = append(sa.errors, fmt.Sprintf("lib.action expects 1 argument, got %d", len(call.Args)))
		}
		return
	}
}

func (sa *SemanticAnalyzer) analyzeMatch(match *ast.MatchStmt) {
	// можно добавить проверку типов
}

func (sa *SemanticAnalyzer) analyzeSafe(safe *ast.SafeStmt) {
	// можно добавить проверки
}

func (sa *SemanticAnalyzer) HasErrors() bool {
	return len(sa.errors) > 0
}

func (sa *SemanticAnalyzer) GetErrors() []string {
	return sa.errors
}
