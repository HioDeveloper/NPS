package interpreter

import (
	"fmt"
	"io/ioutil"
	"os"
	"strconv"
	"strings"

	"nps/pkg/ast"
	"nps/pkg/manager"
	"nps/pkg/parser"
	"nps/pkg/runtime"
)

type Interpreter struct {
	globals map[string]interface{}
	locals  map[string]interface{}
	tasks   map[string]*ast.TaskStmt
}

func NewInterpreter() *Interpreter {
	return &Interpreter{
		globals: make(map[string]interface{}),
		locals:  make(map[string]interface{}),
		tasks:   make(map[string]*ast.TaskStmt),
	}
}

func (i *Interpreter) Run(prog *ast.Program) error {
	expanded, err := i.expandIncludes(prog)
	if err != nil {
		return err
	}

	for _, task := range expanded.Tasks {
		i.tasks[task.Name] = task
	}

	mainTask, ok := i.tasks["main"]
	if !ok {
		return fmt.Errorf("no 'main' task found")
	}
	return i.executeTask(mainTask, []interface{}{})
}

func (i *Interpreter) expandIncludes(prog *ast.Program) (*ast.Program, error) {
	expanded := &ast.Program{
		Includes: prog.Includes,
		Defines:  prog.Defines,
		Tasks:    make([]*ast.TaskStmt, len(prog.Tasks)),
		Safe:     prog.Safe,
	}
	copy(expanded.Tasks, prog.Tasks)

	libPaths, err := manager.GetLibPaths()
	if err != nil {
		return nil, err
	}

	for _, inc := range prog.Includes {
		if inc == "lib" {
			continue
		}
		var foundPath string
		for _, dir := range libPaths {
			path := dir + string(os.PathSeparator) + inc + ".npsl"
			if _, err := ioutil.ReadFile(path); err == nil {
				foundPath = path
				break
			}
		}
		if foundPath == "" {
			return nil, fmt.Errorf("library '%s' not found", inc)
		}
		data, err := ioutil.ReadFile(foundPath)
		if err != nil {
			return nil, fmt.Errorf("reading library %s: %v", inc, err)
		}
		p := parser.NewParser(string(data), libPaths)
		libProg := p.ParseProgram()
		if len(p.Errors) > 0 {
			return nil, fmt.Errorf("parsing library %s: %v", inc, p.Errors)
		}
		for _, task := range libProg.Tasks {
			if _, exists := i.tasks[task.Name]; !exists {
				expanded.Tasks = append(expanded.Tasks, task)
			}
		}
		if len(libProg.Includes) > 0 {
			subProg, err := i.expandIncludes(libProg)
			if err != nil {
				return nil, err
			}
			for _, task := range subProg.Tasks {
				if _, exists := i.tasks[task.Name]; !exists {
					expanded.Tasks = append(expanded.Tasks, task)
				}
			}
		}
	}
	return expanded, nil
}

func (i *Interpreter) executeTask(task *ast.TaskStmt, args []interface{}) error {
	oldLocals := i.locals
	i.locals = make(map[string]interface{})
	for idx, param := range task.Params {
		if idx < len(args) {
			i.locals[param.Name] = args[idx]
		}
	}
	err := i.executeBlock(task.Body)
	i.locals = oldLocals
	return err
}

func (i *Interpreter) executeBlock(block *ast.BlockStmt) error {
	for _, stmt := range block.Statements {
		switch s := stmt.(type) {
		case *ast.LetStmt:
			val := i.evalExpr(s.Value)
			i.locals[s.Name] = val
		case *ast.AssignStmt:
			val := i.evalExpr(s.Value)
			if _, ok := i.locals[s.Name]; ok {
				i.locals[s.Name] = val
			} else if _, ok := i.globals[s.Name]; ok {
				i.globals[s.Name] = val
			} else {
				return fmt.Errorf("variable '%s' not declared", s.Name)
			}
		case *ast.ReturnStmt:
			val := i.evalExpr(s.Value)
			return fmt.Errorf("return %v (not implemented in interpreter)", val)
		case *ast.CallExpr:
			if err := i.executeCall(s); err != nil {
				return err
			}
		case *ast.IfStmt:
			if err := i.executeIf(s); err != nil {
				return err
			}
		case *ast.WhileStmt:
			if err := i.executeWhile(s); err != nil {
				return err
			}
		case *ast.MatchStmt:
			if err := i.executeMatch(s); err != nil {
				return err
			}
		case *ast.BlockStmt:
			if err := i.executeBlock(s); err != nil {
				return err
			}
		default:
			// ignore
		}
	}
	return nil
}

func (i *Interpreter) executeCall(call *ast.CallExpr) error {
	args := make([]interface{}, len(call.Args))
	for idx, arg := range call.Args {
		args[idx] = i.evalExpr(arg)
	}

	if call.Func == "print" {
		for _, arg := range args {
			fmt.Print(arg)
		}
		fmt.Println()
		return nil
	}

	if strings.HasPrefix(call.Func, "lib.") {
		funcName := strings.TrimPrefix(call.Func, "lib.")
		switch funcName {
		case "action":
			if len(args) != 1 {
				return fmt.Errorf("lib.action expects 1 argument")
			}
			mode, ok := args[0].(int)
			if !ok {
				return fmt.Errorf("lib.action expects int argument")
			}
			runtime.Action(mode)
		case "listen":
			if len(args) != 1 {
				return fmt.Errorf("lib.listen expects 1 argument")
			}
			port, ok := args[0].(int)
			if !ok {
				return fmt.Errorf("lib.listen expects port number")
			}
			runtime.Listen(runtime.Port(port))
		case "send":
			// stub
		case "aes_encrypt":
			// stub
		default:
			return fmt.Errorf("unknown lib function: %s", funcName)
		}
		return nil
	}

	task, ok := i.tasks[call.Func]
	if !ok {
		return fmt.Errorf("unknown function: %s", call.Func)
	}
	return i.executeTask(task, args)
}

func (i *Interpreter) executeIf(ifStmt *ast.IfStmt) error {
	cond := i.evalExpr(ifStmt.Condition)
	if isTruthy(cond) {
		return i.executeBlock(ifStmt.Then)
	} else if ifStmt.Else != nil {
		return i.executeBlock(ifStmt.Else)
	}
	return nil
}

func (i *Interpreter) executeWhile(while *ast.WhileStmt) error {
	for {
		cond := i.evalExpr(while.Condition)
		if !isTruthy(cond) {
			break
		}
		if err := i.executeBlock(while.Body); err != nil {
			return err
		}
	}
	return nil
}

func (i *Interpreter) executeMatch(match *ast.MatchStmt) error {
	val := i.evalExpr(match.Value)
	for _, c := range match.Cases {
		pattern := i.evalExpr(c.Pattern)
		if val == pattern {
			switch act := c.Action.(type) {
			case *ast.CallExpr:
				return i.executeCall(act)
			case *ast.BlockStmt:
				return i.executeBlock(act)
			default:
				return nil
			}
		}
	}
	return nil
}

func (i *Interpreter) evalExpr(expr ast.Expr) interface{} {
	switch e := expr.(type) {
	case *ast.IdentExpr:
		if val, ok := i.locals[e.Name]; ok {
			return val
		}
		if val, ok := i.globals[e.Name]; ok {
			return val
		}
		return nil
	case *ast.NumberExpr:
		return e.Value
	case *ast.StringExpr:
		return e.Value
	case *ast.IPExpr:
		parts := strings.Split(e.Value, ".")
		if len(parts) == 4 {
			a, _ := strconv.Atoi(parts[0])
			b, _ := strconv.Atoi(parts[1])
			c, _ := strconv.Atoi(parts[2])
			d, _ := strconv.Atoi(parts[3])
			return int(a)<<24 | int(b)<<16 | int(c)<<8 | int(d)
		}
		return 0
	case *ast.BinOpExpr:
		left := i.evalExpr(e.Left)
		right := i.evalExpr(e.Right)
		return applyBinOp(e.Op, left, right)
	case *ast.UnaryExpr:
		right := i.evalExpr(e.Right)
		return applyUnary(e.Op, right)
	case *ast.CallExpr:
		i.executeCall(e)
		return nil
	default:
		return nil
	}
}

func applyBinOp(op string, left, right interface{}) interface{} {
	l, lok := left.(int)
	r, rok := right.(int)
	if lok && rok {
		switch op {
		case "+":
			return l + r
		case "-":
			return l - r
		case "*":
			return l * r
		case "/":
			if r != 0 {
				return l / r
			}
			return 0
		case "==":
			return l == r
		case "!=":
			return l != r
		case "<":
			return l < r
		case ">":
			return l > r
		case "<=":
			return l <= r
		case ">=":
			return l >= r
		}
	}
	return nil
}

func applyUnary(op string, right interface{}) interface{} {
	if op == "-" {
		if r, ok := right.(int); ok {
			return -r
		}
	}
	if op == "!" {
		if r, ok := right.(bool); ok {
			return !r
		}
	}
	return nil
}

func isTruthy(val interface{}) bool {
	switch v := val.(type) {
	case bool:
		return v
	case int:
		return v != 0
	case string:
		return v != ""
	default:
		return val != nil
	}
}
