package lexer

import (
	"unicode"
)

type TokenType string

const (
	TokenEOF      TokenType = "EOF"
	TokenInclude  TokenType = "#INCLUDE"
	TokenDefine   TokenType = "#DEFINE"
	TokenTask     TokenType = "TASK"
	TokenLet      TokenType = "LET"
	TokenMut      TokenType = "MUT"
	TokenSafe     TokenType = "SAFE"
	TokenMatch    TokenType = "MATCH"
	TokenIf       TokenType = "IF"
	TokenWhile    TokenType = "WHILE"
	TokenReturn   TokenType = "RETURN"
	TokenPrint    TokenType = "PRINT"
	TokenIdent    TokenType = "IDENT"
	TokenNumber   TokenType = "NUMBER"
	TokenString   TokenType = "STRING"
	TokenIP       TokenType = "IP"
	TokenTypeIP   TokenType = "TYPE_IP"
	TokenTypePort TokenType = "TYPE_PORT"
	TokenTypePkt  TokenType = "TYPE_PACKET"
	TokenLPar     TokenType = "LPAR"
	TokenRPar     TokenType = "RPAR"
	TokenLBrace   TokenType = "LBRACE"
	TokenRBrace   TokenType = "RBRACE"
	TokenAssign   TokenType = "ASSIGN"
	TokenColon    TokenType = "COLON"
	TokenSemi     TokenType = "SEMI"
	TokenArrow    TokenType = "ARROW"
	TokenComma    TokenType = "COMMA"
	TokenPlus     TokenType = "PLUS"
	TokenMinus    TokenType = "MINUS"
	TokenStar     TokenType = "STAR"
	TokenSlash    TokenType = "SLASH"
	TokenEq       TokenType = "EQ"
	TokenNeq      TokenType = "NEQ"
	TokenLt       TokenType = "LT"
	TokenGt       TokenType = "GT"
	TokenLe       TokenType = "LE"
	TokenGe       TokenType = "GE"
	TokenAnd      TokenType = "AND"
	TokenOr       TokenType = "OR"
	TokenNot      TokenType = "NOT"
	TokenDot      TokenType = "DOT"
	TokenIllegal  TokenType = "ILLEGAL"
)

type Token struct {
	Type    TokenType
	Literal string
	Line    int
}

type Lexer struct {
	input   string
	pos     int
	readPos int
	ch      byte
	line    int
}

func NewLexer(input string) *Lexer {
	l := &Lexer{input: input, line: 1}
	l.readChar()
	return l
}

func (l *Lexer) readChar() {
	if l.readPos >= len(l.input) {
		l.ch = 0
	} else {
		l.ch = l.input[l.readPos]
	}
	l.pos = l.readPos
	l.readPos++
}

func (l *Lexer) peekChar() byte {
	if l.readPos >= len(l.input) {
		return 0
	}
	return l.input[l.readPos]
}

func (l *Lexer) NextToken() Token {
	var tok Token
	l.skipWhitespaceAndComments()

	switch l.ch {
	case 0:
		tok = Token{Type: TokenEOF, Literal: "", Line: l.line}
	case '(':
		tok = Token{Type: TokenLPar, Literal: "(", Line: l.line}
	case ')':
		tok = Token{Type: TokenRPar, Literal: ")", Line: l.line}
	case '{':
		tok = Token{Type: TokenLBrace, Literal: "{", Line: l.line}
	case '}':
		tok = Token{Type: TokenRBrace, Literal: "}", Line: l.line}
	case '=':
		if l.peekChar() == '=' {
			l.readChar()
			tok = Token{Type: TokenEq, Literal: "==", Line: l.line}
		} else {
			tok = Token{Type: TokenAssign, Literal: "=", Line: l.line}
		}
	case '!':
		if l.peekChar() == '=' {
			l.readChar()
			tok = Token{Type: TokenNeq, Literal: "!=", Line: l.line}
		} else {
			tok = Token{Type: TokenNot, Literal: "!", Line: l.line}
		}
	case '<':
		if l.peekChar() == '=' {
			l.readChar()
			tok = Token{Type: TokenLe, Literal: "<=", Line: l.line}
		} else {
			tok = Token{Type: TokenLt, Literal: "<", Line: l.line}
		}
	case '>':
		if l.peekChar() == '=' {
			l.readChar()
			tok = Token{Type: TokenGe, Literal: ">=", Line: l.line}
		} else {
			tok = Token{Type: TokenGt, Literal: ">", Line: l.line}
		}
	case '+':
		tok = Token{Type: TokenPlus, Literal: "+", Line: l.line}
	case '-':
		if l.peekChar() == '>' {
			l.readChar()
			tok = Token{Type: TokenArrow, Literal: "->", Line: l.line}
		} else {
			tok = Token{Type: TokenMinus, Literal: "-", Line: l.line}
		}
	case '*':
		tok = Token{Type: TokenStar, Literal: "*", Line: l.line}
	case '/':
		tok = Token{Type: TokenSlash, Literal: "/", Line: l.line}
	case '.':
		tok = Token{Type: TokenDot, Literal: ".", Line: l.line}
	case ':':
		tok = Token{Type: TokenColon, Literal: ":", Line: l.line}
	case ',':
		tok = Token{Type: TokenComma, Literal: ",", Line: l.line}
	case ';':
		tok = Token{Type: TokenSemi, Literal: ";", Line: l.line}
	case '#':
		lit := l.readIdentifier()
		if lit == "#include" {
			tok = Token{Type: TokenInclude, Literal: lit, Line: l.line}
		} else if lit == "#define" {
			tok = Token{Type: TokenDefine, Literal: lit, Line: l.line}
		} else {
			tok = Token{Type: TokenIllegal, Literal: lit, Line: l.line}
		}
		return tok
	case '"':
		tok.Type = TokenString
		tok.Literal = l.readString()
		tok.Line = l.line
		return tok
	default:
		if unicode.IsLetter(rune(l.ch)) || l.ch == '_' {
			lit := l.readIdentifier()
			switch lit {
			case "task":
				tok = Token{Type: TokenTask, Literal: lit, Line: l.line}
			case "let":
				tok = Token{Type: TokenLet, Literal: lit, Line: l.line}
			case "mut":
				tok = Token{Type: TokenMut, Literal: lit, Line: l.line}
			case "safe":
				tok = Token{Type: TokenSafe, Literal: lit, Line: l.line}
			case "match":
				tok = Token{Type: TokenMatch, Literal: lit, Line: l.line}
			case "if":
				tok = Token{Type: TokenIf, Literal: lit, Line: l.line}
			case "while":
				tok = Token{Type: TokenWhile, Literal: lit, Line: l.line}
			case "return":
				tok = Token{Type: TokenReturn, Literal: lit, Line: l.line}
			case "print":
				tok = Token{Type: TokenPrint, Literal: lit, Line: l.line}
			case "ip":
				tok = Token{Type: TokenTypeIP, Literal: lit, Line: l.line}
			case "port":
				tok = Token{Type: TokenTypePort, Literal: lit, Line: l.line}
			case "packet":
				tok = Token{Type: TokenTypePkt, Literal: lit, Line: l.line}
			default:
				tok = Token{Type: TokenIdent, Literal: lit, Line: l.line}
			}
			return tok
		} else if unicode.IsDigit(rune(l.ch)) {
			lit := l.readNumber()
			if l.ch == '.' && unicode.IsDigit(rune(l.peekChar())) {
				lit = l.readIP(lit)
				tok = Token{Type: TokenIP, Literal: lit, Line: l.line}
			} else {
				tok = Token{Type: TokenNumber, Literal: lit, Line: l.line}
			}
			return tok
		} else {
			tok = Token{Type: TokenIllegal, Literal: string(l.ch), Line: l.line}
		}
	}

	l.readChar()
	return tok
}

func (l *Lexer) readIdentifier() string {
	start := l.pos
	for unicode.IsLetter(rune(l.ch)) || unicode.IsDigit(rune(l.ch)) || l.ch == '_' || l.ch == '#' {
		l.readChar()
	}
	return l.input[start:l.pos]
}

func (l *Lexer) readNumber() string {
	start := l.pos
	for unicode.IsDigit(rune(l.ch)) {
		l.readChar()
	}
	return l.input[start:l.pos]
}

func (l *Lexer) readIP(first string) string {
	ip := first
	for {
		if l.ch == '.' && unicode.IsDigit(rune(l.peekChar())) {
			ip += string(l.ch)
			l.readChar()
			start := l.pos
			for unicode.IsDigit(rune(l.ch)) {
				l.readChar()
			}
			ip += l.input[start:l.pos]
		} else {
			break
		}
	}
	return ip
}

func (l *Lexer) readString() string {
	l.readChar()
	start := l.pos
	for l.ch != '"' && l.ch != 0 {
		if l.ch == '\\' {
			l.readChar()
		}
		l.readChar()
	}
	str := l.input[start:l.pos]
	if l.ch == '"' {
		l.readChar()
	}
	return str
}

func (l *Lexer) skipWhitespaceAndComments() {
	for {
		if l.ch == ' ' || l.ch == '\t' || l.ch == '\r' || l.ch == '\n' {
			if l.ch == '\n' {
				l.line++
			}
			l.readChar()
			continue
		}
		if l.ch == '/' && l.peekChar() == '/' {
			for l.ch != '\n' && l.ch != 0 {
				l.readChar()
			}
			continue
		}
		break
	}
}
