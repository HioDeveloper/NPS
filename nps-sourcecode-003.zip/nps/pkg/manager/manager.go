package manager

import (
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
)

type Manager struct {
	repoURL string
}

func NewManager(repoURL string) *Manager {
	return &Manager{repoURL: repoURL}
}

func (m *Manager) Install(libName string) error {
	globalDir, err := GlobalLibsDir()
	if err != nil {
		return err
	}
	if err := os.MkdirAll(globalDir, 0755); err != nil {
		return err
	}
	url := fmt.Sprintf("%s/%s/main.npsl", m.repoURL, libName)
	resp, err := http.Get(url)
	if err != nil {
		return fmt.Errorf("failed to download: %v", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("library '%s' not found (status %d)", libName, resp.StatusCode)
	}
	target := filepath.Join(globalDir, libName+".npsl")
	out, err := os.Create(target)
	if err != nil {
		return err
	}
	defer out.Close()
	if _, err := io.Copy(out, resp.Body); err != nil {
		return err
	}
	fmt.Printf("Installed %s -> %s\n", libName, target)
	return nil
}

func (m *Manager) List() error {
	globalDir, err := GlobalLibsDir()
	if err != nil {
		return err
	}
	localDir := LocalLibsDir()
	libs := make(map[string]string)
	for _, dir := range []string{localDir, globalDir} {
		files, err := filepath.Glob(filepath.Join(dir, "*.npsl"))
		if err != nil {
			continue
		}
		for _, f := range files {
			name := filepath.Base(f)
			libs[name] = dir
		}
	}
	if len(libs) == 0 {
		fmt.Println("No libraries installed.")
		return nil
	}
	fmt.Println("Installed libraries:")
	for name, dir := range libs {
		fmt.Printf("  %s  (%s)\n", name, dir)
	}
	return nil
}

func (m *Manager) Remove(libName string) error {
	globalDir, err := GlobalLibsDir()
	if err != nil {
		return err
	}
	filePath := filepath.Join(globalDir, libName+".npsl")
	if _, err := os.Stat(filePath); os.IsNotExist(err) {
		return fmt.Errorf("library '%s' not found in global install", libName)
	}
	if err := os.Remove(filePath); err != nil {
		return err
	}
	fmt.Printf("Removed %s\n", libName)
	return nil
}

func (m *Manager) Update(libName string) error {
	if err := m.Remove(libName); err != nil {
		return err
	}
	return m.Install(libName)
}

func (m *Manager) ListInstalled() ([]string, error) {
	globalDir, err := GlobalLibsDir()
	if err != nil {
		return nil, err
	}
	files, err := filepath.Glob(filepath.Join(globalDir, "*.npsl"))
	if err != nil {
		return nil, err
	}
	var libs []string
	for _, f := range files {
		name := filepath.Base(f)
		libs = append(libs, strings.TrimSuffix(name, ".npsl"))
	}
	return libs, nil
}
