package manager

import (
	"os"
	"path/filepath"
)

const (
	GlobalLibsDirName = ".nps"
	LocalLibsDirName  = "nps_libs"
)

func GlobalLibsDir() (string, error) {
	home, err := os.UserHomeDir()
	if err != nil {
		return "", err
	}
	return filepath.Join(home, GlobalLibsDirName, "libs"), nil
}

func LocalLibsDir() string {
	return LocalLibsDirName
}

func GetLibPaths() ([]string, error) {
	global, err := GlobalLibsDir()
	if err != nil {
		return nil, err
	}
	local := LocalLibsDir()
	return []string{local, global}, nil
}
