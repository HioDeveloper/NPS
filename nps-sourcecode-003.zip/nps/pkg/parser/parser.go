package parser

import (
	"fmt"
	"os"
	"strconv"

	"nps/pkg/ast"
	"nps/pkg/lexer"
)

type Parser struct {
	tokens   []lexer.Token
	pos      int
	Errors   []string
	libPaths []string
}

func NewParser(input string, libPaths []string) *Parser {
	l := lexer.NewLexer(input)
	var tokens []lexer.Token
	for {
		tok := l.NextToken()
		tokens = append(tokens, tok)
		if tok.Type == lexer.TokenEOF {
			break
		}
	}
	return &Parser{tokens: tokens, libPaths: libPaths, Errors: []string{}}
}

func (p *Parser) curToken() lexer.Token {
	if p.pos >= len(p.tokens) {
		return lexer.Token{Type: lexer.TokenEOF, Literal: "", Line: 0}
	}
	return p.tokens[p.pos]
}

func (p *Parser) peekToken() lexer.Token {
	if p.pos+1 >= len(p.tokens) {
		return lexer.Token{Type: lexer.TokenEOF, Literal: "", Line: 0}
	}
	return p.tokens[p.pos+1]
}

func (p *Parser) advance() {
	p.pos++
}

func (p *Parser) expect(t lexer.TokenType) lexer.Token {
	tok := p.curToken()
	if tok.Type != t {
		p.Errors = append(p.Errors, fmt.Sprintf("expected %s, got %s at line %d", t, tok.Type, tok.Line))
	}
	p.advance()
	return tok
}

func (p *Parser) skipSemicolon() {
	if p.curToken().Type == lexer.TokenSemi {
		p.advance()
	}
}

func (p *Parser) ParseProgram() *ast.Program {
	prog := &ast.Program{
		Includes: []string{},
		Defines:  map[string]string{},
		Tasks:    []*ast.TaskStmt{},
	}

	for p.curToken().Type != lexer.TokenEOF {
		tok := p.curToken()
		switch tok.Type {
		case lexer.TokenInclude:
			p.advance()
			libTok := p.expect(lexer.TokenIdent)
			libName := libTok.Literal
			if p.resolveInclude(libName) {
				prog.Includes = append(prog.Includes, libName)
			} else {
				p.Errors = append(p.Errors, fmt.Sprintf("library '%s' not found", libName))
			}
		case lexer.TokenDefine:
			p.advance()
			name := p.expect(lexer.TokenIdent)
			val := p.expect(lexer.TokenNumber)
			prog.Defines[name.Literal] = val.Literal
		case lexer.TokenTask:
			task := p.parseTask()
			prog.Tasks = append(prog.Tasks, task)
		case lexer.TokenSafe:
			safe := p.parseSafe()
			prog.Safe = safe
		default:
			p.Errors = append(p.Errors, fmt.Sprintf("unexpected token %s at line %d", tok.Type, tok.Line))
			p.advance()
		}
	}
	return prog
}

func (p *Parser) resolveInclude(libName string) bool {
	if libName == "lib" {
		return true
	}
	for _, dir := range p.libPaths {
		if dir == "" {
			continue
		}
		path := dir + string(os.PathSeparator) + libName + ".npsl"
		if _, err := os.Stat(path); err == nil {
			return true
		}
	}
	return false
}

func (p *Parser) parseTask() *ast.TaskStmt {
	p.expect(lexer.TokenTask)
	name := p.expect(lexer.TokenIdent).Literal
	p.expect(lexer.TokenLPar)
	var params []struct{ Name, Type string }
	if p.curToken().Type != lexer.TokenRPar {
		for {
			pName := p.expect(lexer.TokenIdent).Literal
			p.expect(lexer.TokenColon)
			pType := p.parseType()
			params = append(params, struct{ Name, Type string }{pName, pType})
			if p.curToken().Type == lexer.TokenComma {
				p.advance()
				continue
			}
			break
		}
	}
	p.expect(lexer.TokenRPar)
	body := p.parseBlock()
	return &ast.TaskStmt{Name: name, Params: params, Body: body, Line: p.curToken().Line}
}

func (p *Parser) parseType() string {
	tok := p.curToken()
	switch tok.Type {
	case lexer.TokenTypeIP:
		p.advance()
		return "ip"
	case lexer.TokenTypePort:
		p.advance()
		return "port"
	case lexer.TokenTypePkt:
		p.advance()
		return "packet"
	case lexer.TokenIdent:
		p.advance()
		return tok.Literal
	default:
		p.Errors = append(p.Errors, fmt.Sprintf("expected type, got %s", tok.Type))
		return ""
	}
}

func (p *Parser) parseBlock() *ast.BlockStmt {
	p.expect(lexer.TokenLBrace)
	block := &ast.BlockStmt{Line: p.curToken().Line, Statements: []ast.Node{}}
	for p.curToken().Type != lexer.TokenRBrace && p.curToken().Type != lexer.TokenEOF {
		stmt := p.parseStatement()
		if stmt != nil {
			block.Statements = append(block.Statements, stmt)
		}
		p.skipSemicolon()
	}
	p.expect(lexer.TokenRBrace)
	return block
}

func (p *Parser) parseStatement() ast.Node {
	tok := p.curToken()
	switch tok.Type {
	case lexer.TokenLet:
		return p.parseLet(false)
	case lexer.TokenMut:
		if p.peekToken().Type == lexer.TokenIdent {
			return p.parseLet(true)
		}
		p.Errors = append(p.Errors, fmt.Sprintf("expected identifier after mut, got %s", p.peekToken().Type))
		p.advance()
		return nil
	case lexer.TokenReturn:
		return p.parseReturn()
	case lexer.TokenIf:
		return p.parseIf()
	case lexer.TokenWhile:
		return p.parseWhile()
	case lexer.TokenMatch:
		return p.parseMatch()
	case lexer.TokenPrint:
		return p.parsePrintCall()
	case lexer.TokenIdent:
		if p.peekToken().Type == lexer.TokenAssign {
			return p.parseAssignment()
		}
		return p.parseCallOrExpr()
	default:
		p.Errors = append(p.Errors, fmt.Sprintf("unexpected statement token %s at line %d", tok.Type, tok.Line))
		p.advance()
		return nil
	}
}

func (p *Parser) parseLet(mutable bool) *ast.LetStmt {
	if !mutable {
		p.expect(lexer.TokenLet)
	} else {
		p.expect(lexer.TokenMut)
	}
	name := p.expect(lexer.TokenIdent).Literal
	var typ string
	if p.curToken().Type == lexer.TokenColon {
		p.advance()
		typ = p.parseType()
	}
	p.expect(lexer.TokenAssign)
	value := p.parseExpression()
	return &ast.LetStmt{Name: name, Type: typ, Mutable: mutable, Value: value, Line: p.curToken().Line}
}

func (p *Parser) parseAssignment() *ast.AssignStmt {
	name := p.expect(lexer.TokenIdent).Literal
	p.expect(lexer.TokenAssign)
	value := p.parseExpression()
	return &ast.AssignStmt{Name: name, Value: value, Line: p.curToken().Line}
}

func (p *Parser) parseReturn() *ast.ReturnStmt {
	p.expect(lexer.TokenReturn)
	val := p.parseExpression()
	return &ast.ReturnStmt{Value: val, Line: p.curToken().Line}
}

func (p *Parser) parseIf() *ast.IfStmt {
	p.expect(lexer.TokenIf)
	cond := p.parseExpression()
	then := p.parseBlock()
	var els *ast.BlockStmt
	if p.curToken().Type == lexer.TokenIdent && p.curToken().Literal == "else" {
		p.advance()
		els = p.parseBlock()
	}
	return &ast.IfStmt{Condition: cond, Then: then, Else: els, Line: p.curToken().Line}
}

func (p *Parser) parseWhile() *ast.WhileStmt {
	p.expect(lexer.TokenWhile)
	cond := p.parseExpression()
	body := p.parseBlock()
	return &ast.WhileStmt{Condition: cond, Body: body, Line: p.curToken().Line}
}

func (p *Parser) parseMatch() *ast.MatchStmt {
	p.expect(lexer.TokenMatch)
	val := p.parseExpression()
	p.expect(lexer.TokenLBrace)
	var cases []ast.MatchCase
	for p.curToken().Type != lexer.TokenRBrace && p.curToken().Type != lexer.TokenEOF {
		pattern := p.parseExpression()
		p.expect(lexer.TokenArrow)
		var action ast.Node
		if p.curToken().Type == lexer.TokenLBrace {
			action = p.parseBlock()
		} else {
			action = p.parseExpression()
		}
		cases = append(cases, ast.MatchCase{Pattern: pattern, Action: action})
		p.skipSemicolon()
	}
	p.expect(lexer.TokenRBrace)
	return &ast.MatchStmt{Value: val, Cases: cases, Line: p.curToken().Line}
}

func (p *Parser) parsePrintCall() *ast.CallExpr {
	p.expect(lexer.TokenPrint)
	p.expect(lexer.TokenLPar)
	var args []ast.Expr
	if p.curToken().Type != lexer.TokenRPar {
		args = append(args, p.parseExpression())
		for p.curToken().Type == lexer.TokenComma {
			p.advance()
			args = append(args, p.parseExpression())
		}
	}
	p.expect(lexer.TokenRPar)
	return &ast.CallExpr{Func: "print", Args: args, Line: p.curToken().Line}
}

func (p *Parser) parseCallOrExpr() ast.Node {
	return p.parseExpression()
}

func (p *Parser) parseExpression() ast.Expr {
	return p.parseBinary(0)
}

func (p *Parser) parseBinary(prec int) ast.Expr {
	left := p.parseUnary()
	for {
		op := p.curToken()
		opPrec := p.getPrecedence(op.Type)
		if opPrec == 0 || opPrec < prec {
			break
		}
		p.advance()
		right := p.parseBinary(opPrec + 1)
		left = &ast.BinOpExpr{Left: left, Op: op.Literal, Right: right, Line: op.Line}
	}
	return left
}

func (p *Parser) getPrecedence(t lexer.TokenType) int {
	switch t {
	case lexer.TokenPlus, lexer.TokenMinus:
		return 1
	case lexer.TokenStar, lexer.TokenSlash:
		return 2
	case lexer.TokenEq, lexer.TokenNeq, lexer.TokenLt, lexer.TokenGt, lexer.TokenLe, lexer.TokenGe:
		return 3
	case lexer.TokenAnd:
		return 4
	case lexer.TokenOr:
		return 5
	default:
		return 0
	}
}

func (p *Parser) parseUnary() ast.Expr {
	tok := p.curToken()
	switch tok.Type {
	case lexer.TokenNot, lexer.TokenMinus:
		p.advance()
		right := p.parseUnary()
		return &ast.UnaryExpr{Op: tok.Literal, Right: right, Line: tok.Line}
	default:
		return p.parsePrimary()
	}
}

func (p *Parser) parsePrimary() ast.Expr {
	tok := p.curToken()
	switch tok.Type {
	case lexer.TokenIdent:
		name := tok.Literal
		p.advance()
		for p.curToken().Type == lexer.TokenDot {
			p.advance()
			if p.curToken().Type != lexer.TokenIdent {
				p.Errors = append(p.Errors, fmt.Sprintf("expected identifier after '.' at line %d", p.curToken().Line))
				break
			}
			name += "." + p.curToken().Literal
			p.advance()
		}
		if p.curToken().Type == lexer.TokenLPar {
			return p.parseCallWithName(name)
		}
		return &ast.IdentExpr{Name: name, Line: tok.Line}
	case lexer.TokenNumber:
		val, _ := strconv.Atoi(tok.Literal)
		p.advance()
		return &ast.NumberExpr{Value: val, Line: tok.Line}
	case lexer.TokenIP:
		ip := tok.Literal
		p.advance()
		return &ast.IPExpr{Value: ip, Line: tok.Line}
	case lexer.TokenString:
		str := tok.Literal
		p.advance()
		return &ast.StringExpr{Value: str, Line: tok.Line}
	case lexer.TokenLPar:
		p.advance()
		expr := p.parseExpression()
		p.expect(lexer.TokenRPar)
		return expr
	default:
		p.Errors = append(p.Errors, fmt.Sprintf("unexpected primary token %s at line %d", tok.Type, tok.Line))
		p.advance()
		return nil
	}
}

func (p *Parser) parseCallWithName(name string) *ast.CallExpr {
	p.expect(lexer.TokenLPar)
	var args []ast.Expr
	if p.curToken().Type != lexer.TokenRPar {
		args = append(args, p.parseExpression())
		for p.curToken().Type == lexer.TokenComma {
			p.advance()
			args = append(args, p.parseExpression())
		}
	}
	p.expect(lexer.TokenRPar)
	return &ast.CallExpr{Func: name, Args: args, Line: p.curToken().Line}
}

func (p *Parser) parseSafe() *ast.SafeStmt {
	p.expect(lexer.TokenSafe)
	p.expect(lexer.TokenLPar)
	p.expect(lexer.TokenIdent)
	p.expect(lexer.TokenAssign)
	maxProc := p.expect(lexer.TokenNumber)
	p.expect(lexer.TokenRPar)
	body := p.parseBlock()
	val, _ := strconv.Atoi(maxProc.Literal)
	return &ast.SafeStmt{MaxProcesses: val, Body: body, Line: maxProc.Line}
}
