package runtime

import "fmt"

type IP uint32
type Port uint16

type Packet struct {
	Src   IP
	Dst   IP
	SPort Port
	DPort Port
	Data  []byte
}

// Глобальные функции (без структуры)
func Action(mode int) {
	if mode == 1 {
		fmt.Println("[NPS] Action: ACCEPT")
	} else if mode == 0 {
		fmt.Println("[NPS] Action: DROP (block)")
	} else {
		fmt.Println("[NPS] Action: UNKNOWN")
	}
}

func Listen(port Port) Packet {
	fmt.Printf("[NPS] Listening on port %d\n", port)
	return Packet{
		Src:   IP(0xC0A80A03),
		Dst:   0,
		SPort: port,
		DPort: 0,
		Data:  []byte("test"),
	}
}

func Send(pkt Packet, dest IP) {
	fmt.Printf("[NPS] Sending packet to %d\n", dest)
}

func AESEncrypt(data []byte, key []byte) []byte {
	return data
}
